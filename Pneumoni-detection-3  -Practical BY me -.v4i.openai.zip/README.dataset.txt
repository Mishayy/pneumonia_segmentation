# Pneumoni-detection-3  (Practical BY me ) > 2024-06-27 2:36pm
https://universe.roboflow.com/project-gcm3p/pneumoni-detection-3-practical-by-me

Provided by a Roboflow user
License: CC BY 4.0

